// src/types/index.ts
// Shared types for the Bahir Dar AI Traffic Management dashboard.
// These describe the data the FastAPI backend streams over WebSocket.
// The frontend ONLY displays this data; it never computes signal logic itself.

export type Congestion = "low" | "medium" | "high";

export type VehicleLight = "green" | "yellow" | "red";

export type PedestrianSignal = "wait" | "walk";

export interface TrafficAlert {
  id: string;
  /** Free-form category: e.g. "congestion", "safety", "info" */
  type: string;
  message: string;
  /** Epoch milliseconds */
  time: number;
}

export interface TrafficState {
  /** Epoch milliseconds */
  timestamp: number;
  vehicleCount: number;
  pedestrianCount: number;
  congestion: Congestion;
  /** Recommended green-light duration in seconds, computed by the backend. */
  recommendedGreenSeconds: number;
  vehicleLight: VehicleLight;
  pedestrianSignal: PedestrianSignal;
  alerts: TrafficAlert[];
}

/** Optional extension of TrafficState when VITE_ENABLE_SPEED="true" */
export interface SpeedRow {
  id: string;
  /** Epoch milliseconds */
  time: number;
  /** km/h - always labelled "estimated" in the UI */
  estimatedSpeed: number;
  /** km/h */
  limit: number;
  status: "ok" | "warning" | "over";
}

/** Connection status surfaced by useTrafficStream */
export type StreamStatus = "connecting" | "live" | "offline";

/** Upload lifecycle for the video panel */
export type UploadStatus = "idle" | "uploading" | "success" | "error";

/** Report generation lifecycle */
export type ReportStatus = "idle" | "loading" | "success" | "error";
