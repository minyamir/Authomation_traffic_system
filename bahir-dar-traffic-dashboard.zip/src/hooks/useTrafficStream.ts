// src/hooks/useTrafficStream.ts
//
// Subscribes to the live traffic-state stream.
// - When VITE_USE_MOCK=true (default for demo), uses the in-browser mock.
// - Otherwise opens a WebSocket to VITE_WS_URL, auto-reconnects with backoff.
// - Exposes the latest state, a rolling 60-sample history, and a status pill.
//
// The hook ONLY displays data; it never computes signal logic.

import { useEffect, useState } from "react";
import type { StreamStatus, TrafficState } from "@/types";
import { USE_MOCK } from "@/api/client";
import { wsStreamUrl } from "@/api/endpoints";
import { getMockStream } from "@/api/mock";

const MAX_HISTORY = 60;
const MAX_RECONNECT_DELAY_MS = 8_000;
const INITIAL_RECONNECT_DELAY_MS = 500;

export interface UseTrafficStream {
  state: TrafficState | null;
  history: TrafficState[];
  status: StreamStatus;
  /** True only when running off the mock emitter. */
  isMock: boolean;
  /** Last error message from the WebSocket (empty string when none). */
  error: string;
}

export function useTrafficStream(): UseTrafficStream {
  const [state, setState] = useState<TrafficState | null>(null);
  const [history, setHistory] = useState<TrafficState[]>([]);
  const [status, setStatus] = useState<StreamStatus>("connecting");
  const [error, setError] = useState<string>("");

  useEffect(() => {
    let cancelled = false;
    const cleanups: Array<() => void> = [];

    function applyState(s: TrafficState) {
      if (cancelled) return;
      setState(s);
      setHistory((prev) => {
        const next = [...prev, s];
        if (next.length > MAX_HISTORY) next.splice(0, next.length - MAX_HISTORY);
        return next;
      });
    }

    if (USE_MOCK) {
      setStatus("live");
      setError("");
      const stream = getMockStream();
      const unsub = stream.subscribe(applyState);
      cleanups.push(unsub);
    } else {
      // ----- Real WebSocket branch -----
      let ws: WebSocket | null = null;
      let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
      let closedByUs = false;
      let reconnectDelay = INITIAL_RECONNECT_DELAY_MS;

      function scheduleReconnect() {
        if (reconnectTimer || cancelled) return;
        const delay = reconnectDelay;
        reconnectTimer = setTimeout(() => {
          reconnectTimer = null;
          reconnectDelay = Math.min(
            reconnectDelay * 2,
            MAX_RECONNECT_DELAY_MS,
          );
          connect();
        }, delay);
      }

      function connect() {
        if (cancelled) return;
        const url = wsStreamUrl();
        closedByUs = false;
        setStatus("connecting");
        try {
          ws = new WebSocket(url);
        } catch (err) {
          setError(err instanceof Error ? err.message : "WebSocket failed");
          setStatus("offline");
          scheduleReconnect();
          return;
        }

        ws.onopen = () => {
          reconnectDelay = INITIAL_RECONNECT_DELAY_MS;
          setStatus("live");
          setError("");
        };

        ws.onmessage = (ev) => {
          let parsed: unknown;
          try {
            parsed = JSON.parse(typeof ev.data === "string" ? ev.data : "");
          } catch {
            setError("Received malformed message from server");
            return;
          }
          if (!isTrafficState(parsed)) {
            setError("Received unexpected payload from server");
            return;
          }
          applyState(parsed);
        };

        ws.onerror = () => {
          setError("WebSocket error — reconnecting…");
        };

        ws.onclose = () => {
          ws = null;
          if (closedByUs || cancelled) return;
          setStatus("offline");
          scheduleReconnect();
        };
      }

      connect();

      cleanups.push(() => {
        closedByUs = true;
        if (reconnectTimer) {
          clearTimeout(reconnectTimer);
          reconnectTimer = null;
        }
        if (ws) {
          ws.close();
          ws = null;
        }
      });
    }

    return () => {
      cancelled = true;
      for (const fn of cleanups) {
        try {
          fn();
        } catch {
          /* noop */
        }
      }
    };
  }, []);

  return {
    state,
    history,
    status,
    isMock: USE_MOCK,
    error,
  };
}

// Minimal runtime guard for the WebSocket payload.
function isTrafficState(v: unknown): v is TrafficState {
  if (!v || typeof v !== "object") return false;
  const o = v as Record<string, unknown>;
  return (
    typeof o.timestamp === "number" &&
    typeof o.vehicleCount === "number" &&
    typeof o.pedestrianCount === "number" &&
    (o.congestion === "low" ||
      o.congestion === "medium" ||
      o.congestion === "high") &&
    typeof o.recommendedGreenSeconds === "number" &&
    (o.vehicleLight === "green" ||
      o.vehicleLight === "yellow" ||
      o.vehicleLight === "red") &&
    (o.pedestrianSignal === "wait" || o.pedestrianSignal === "walk") &&
    Array.isArray(o.alerts)
  );
}
