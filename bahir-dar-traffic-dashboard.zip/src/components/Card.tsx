// src/components/Card.tsx
import type { ReactNode } from "react";

interface CardProps {
  title?: ReactNode;
  subtitle?: ReactNode;
  /** Right-aligned actions (e.g. buttons or status pills). */
  action?: ReactNode;
  /** Padding toggle. Defaults to true. */
  padded?: boolean;
  className?: string;
  bodyClassName?: string;
  children: ReactNode;
  /** Optional id for aria-labelledby wiring. */
  id?: string;
}

export function Card({
  title,
  subtitle,
  action,
  padded = true,
  className = "",
  bodyClassName = "",
  children,
  id,
}: CardProps) {
  const hasHeader = title || subtitle || action;
  return (
    <section
      id={id}
      className={`card-base flex flex-col ${className}`}
      aria-label={typeof title === "string" ? title : undefined}
    >
      {hasHeader && (
        <header className="flex items-start justify-between gap-3 border-b border-control-800 px-4 py-3">
          <div className="min-w-0">
            {title && (
              <h2 className="truncate text-sm font-semibold text-slate-100">
                {title}
              </h2>
            )}
            {subtitle && (
              <p className="mt-0.5 text-xs text-slate-400">{subtitle}</p>
            )}
          </div>
          {action && <div className="shrink-0">{action}</div>}
        </header>
      )}
      <div className={`${padded ? "p-4" : ""} ${bodyClassName} flex-1`}>
        {children}
      </div>
    </section>
  );
}

export default Card;
