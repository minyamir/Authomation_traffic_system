// src/components/TrafficLight.tsx
import type { VehicleLight } from "@/types";

interface TrafficLightProps {
  light: VehicleLight;
  /** Seconds remaining in the current phase, when known (drives the small label). */
  secondsRemaining?: number;
}

interface LightDescriptor {
  label: string; // short label shown next to the light (never rely on color alone)
  color: string; // base color when LIT
  glow: string; // glow when lit
  dim: string; // color when unlit
}

const LIGHTS: Record<"red" | "yellow" | "green", LightDescriptor> = {
  red: {
    label: "STOP",
    color: "bg-red-500",
    glow: "shadow-[0_0_18px_4px_rgba(239,68,68,0.7)]",
    dim: "bg-red-500/15",
  },
  yellow: {
    label: "CAUTION",
    color: "bg-amber-400",
    glow: "shadow-[0_0_18px_4px_rgba(250,204,21,0.7)]",
    dim: "bg-amber-400/15",
  },
  green: {
    label: "GO",
    color: "bg-green-500",
    glow: "shadow-[0_0_18px_4px_rgba(34,197,94,0.7)]",
    dim: "bg-green-500/15",
  },
};

export function TrafficLight({
  light,
  secondsRemaining,
}: TrafficLightProps) {
  const order: Array<"red" | "yellow" | "green"> = ["red", "yellow", "green"];
  return (
    <div className="flex items-center gap-4">
      <div
        className="rounded-2xl border border-control-800 bg-control-950 p-3"
        role="img"
        aria-label={`Vehicle traffic light: ${light}`}
      >
        <div className="flex flex-col gap-3">
          {order.map((key) => {
            const desc = LIGHTS[key];
            const lit = light === key;
            return (
              <div
                key={key}
                aria-hidden="true"
                className={`h-12 w-12 rounded-full transition-all duration-200 ${
                  lit ? `${desc.color} ${desc.glow}` : desc.dim
                }`}
              />
            );
          })}
        </div>
      </div>
      <div className="flex flex-col gap-3 py-1">
        {order.map((key) => {
          const desc = LIGHTS[key];
          const lit = light === key;
          return (
            <div key={key} className="flex h-12 items-center">
              <span
                className={`text-xs font-semibold tracking-widest ${
                  lit ? "text-slate-100" : "text-slate-600"
                }`}
              >
                {desc.label}
              </span>
            </div>
          );
        })}
        {typeof secondsRemaining === "number" && (
          <p className="mt-1 text-xs text-slate-400" aria-live="polite">
            {secondsRemaining > 0
              ? `${secondsRemaining}s remaining`
              : "transitioning…"}
          </p>
        )}
      </div>
    </div>
  );
}

export default TrafficLight;
