// src/components/CongestionBadge.tsx
import type { Congestion } from "@/types";

interface CongestionBadgeProps {
  level: Congestion;
}

const STYLES: Record<Congestion, string> = {
  low: "bg-green-500/10 text-green-300 border border-green-500/30",
  medium: "bg-amber-400/10 text-amber-300 border border-amber-400/30",
  high: "bg-red-500/10 text-red-300 border border-red-500/30",
};

const LABELS: Record<Congestion, string> = {
  low: "LOW",
  medium: "MEDIUM",
  high: "HIGH",
};

const DOTS: Record<Congestion, string> = {
  low: "bg-green-500",
  medium: "bg-amber-400",
  high: "bg-red-500",
};

export function CongestionBadge({ level }: CongestionBadgeProps) {
  return (
    <span
      className={`inline-flex items-center gap-2 rounded-full px-3 py-1 text-sm font-semibold ${STYLES[level]}`}
      role="status"
      aria-label={`Congestion level: ${level}`}
    >
      <span aria-hidden="true" className={`h-2 w-2 rounded-full ${DOTS[level]}`} />
      {LABELS[level]}
    </span>
  );
}

export default CongestionBadge;
