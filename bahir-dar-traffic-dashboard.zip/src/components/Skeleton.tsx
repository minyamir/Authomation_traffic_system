// src/components/Skeleton.tsx
interface SkeletonProps {
  className?: string;
  /** Accessible label, defaults to "Loading…". */
  label?: string;
}

export function Skeleton({ className = "", label = "Loading…" }: SkeletonProps) {
  return (
    <div
      role="status"
      aria-label={label}
      className={`relative overflow-hidden rounded-md bg-control-800/70 ${className}`}
    >
      <div className="absolute inset-0 -translate-x-full animate-[shimmer_1.6s_infinite] bg-gradient-to-r from-transparent via-slate-700/30 to-transparent" />
      <span className="sr-only">{label}</span>
    </div>
  );
}

export default Skeleton;
