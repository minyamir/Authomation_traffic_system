// src/components/ReportCard.tsx
// "AI Traffic Report" card — calls POST /report with the latest state and shows
// the returned text. Hidden entirely when VITE_ENABLE_REPORT !== "true".

import { useCallback, useState } from "react";
import type { ReportStatus, TrafficState } from "@/types";
import { Card } from "./Card";
import { Skeleton } from "./Skeleton";
import { ErrorBanner } from "./ErrorBanner";
import { postJson, USE_MOCK } from "@/api/client";
import { ENDPOINT_REPORT } from "@/api/endpoints";
import { mockGenerateReport } from "@/api/mock";
import { showToast } from "./Toast";

interface ReportCardProps {
  state: TrafficState | null;
}

interface ReportResponse {
  report?: string;
  text?: string;
  content?: string;
}

export function ReportCard({ state }: ReportCardProps) {
  const [status, setStatus] = useState<ReportStatus>("idle");
  const [report, setReport] = useState<string>("");
  const [error, setError] = useState<string>("");

  const onGenerate = useCallback(async () => {
    if (!state) return;
    setStatus("loading");
    setError("");
    try {
      let text: string;
      if (USE_MOCK) {
        // Simulate latency so loading state is visible.
        await new Promise((r) => setTimeout(r, 700));
        text = mockGenerateReport(state);
      } else {
        const res = await postJson<ReportResponse>(ENDPOINT_REPORT, state);
        text = res.report ?? res.text ?? res.content ?? "";
        if (!text) throw new Error("Backend returned an empty report");
      }
      setReport(text);
      setStatus("success");
      showToast({ tone: "success", message: "Report generated." });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to generate report";
      setError(msg);
      setStatus("error");
      showToast({ tone: "error", message: msg });
    }
  }, [state]);

  return (
    <Card
      title="AI Traffic Report"
      subtitle="Generated from the latest observed state"
      action={
        <button
          type="button"
          onClick={onGenerate}
          disabled={!state || status === "loading"}
          className="inline-flex items-center gap-1.5 rounded-md bg-sky-500 px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-sky-400 disabled:cursor-not-allowed disabled:bg-slate-700 disabled:text-slate-400"
        >
          {status === "loading" ? (
            <>
              <Spinner /> Generating…
            </>
          ) : (
            <>Generate report</>
          )}
        </button>
      }
    >
      {status === "idle" && !report && (
        <div className="flex h-full min-h-[120px] flex-col items-center justify-center text-center">
          <ReportIcon />
          <p className="mt-2 text-sm text-slate-400">
            Click <span className="font-semibold text-slate-200">Generate report</span> to
            produce an AI summary of the current intersection state.
          </p>
          {!state && (
            <p className="mt-1 text-xs text-slate-500">
              Waiting for the first traffic sample…
            </p>
          )}
        </div>
      )}

      {status === "loading" && (
        <div className="space-y-2">
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-4 w-2/3" />
          <Skeleton className="h-4 w-5/6" />
          <Skeleton className="h-4 w-1/2" />
        </div>
      )}

      {status === "error" && (
        <ErrorBanner
          message={error}
          onRetry={onGenerate}
        />
      )}

      {status === "success" && report && (
        <pre className="max-h-[260px] overflow-auto whitespace-pre-wrap rounded-md border border-control-800 bg-control-950/60 p-3 font-mono text-xs leading-relaxed text-slate-200 animate-fade-in">
          {report}
        </pre>
      )}
    </Card>
  );
}

function Spinner() {
  return (
    <span
      aria-hidden="true"
      className="inline-block h-3 w-3 animate-spin rounded-full border-2 border-white/40 border-t-white"
    />
  );
}

function ReportIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-8 w-8 text-slate-500"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <path d="M14 2v6h6" />
      <path d="M8 13h8" />
      <path d="M8 17h6" />
    </svg>
  );
}

export default ReportCard;
