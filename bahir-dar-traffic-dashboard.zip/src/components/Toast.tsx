// src/components/Toast.tsx
// Lightweight toast host. Call showToast({ tone, message }) via the hook.
import { useEffect, useState } from "react";

export type ToastTone = "info" | "success" | "error";

export interface ToastMessage {
  id: string;
  tone: ToastTone;
  message: string;
  /** Auto-dismiss ms. Default 3500. */
  duration?: number;
}

let pushFn: ((t: Omit<ToastMessage, "id">) => void) | null = null;

/** Push a toast from anywhere in the app. No-op if the host isn't mounted. */
export function showToast(t: Omit<ToastMessage, "id">): void {
  if (pushFn) pushFn(t);
}

const TONE_STYLES: Record<ToastTone, string> = {
  info: "bg-control-900 border-sky-500/40 text-sky-200",
  success: "bg-control-900 border-green-500/40 text-green-200",
  error: "bg-control-900 border-red-500/40 text-red-200",
};

const TONE_ICON: Record<ToastTone, string> = {
  info: "ℹ",
  success: "✓",
  error: "!",
};

export function ToastHost() {
  const [items, setItems] = useState<ToastMessage[]>([]);

  useEffect(() => {
    pushFn = (t) => {
      const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const duration = t.duration ?? 3500;
      setItems((prev) => [...prev, { ...t, id, duration }]);
      window.setTimeout(() => {
        setItems((prev) => prev.filter((x) => x.id !== id));
      }, duration);
    };
    return () => {
      pushFn = null;
    };
  }, []);

  return (
    <div
      className="pointer-events-none fixed bottom-4 right-4 z-50 flex w-[min(92vw,360px)] flex-col gap-2"
      aria-live="polite"
      aria-atomic="false"
    >
      {items.map((t) => (
        <div
          key={t.id}
          role="status"
          className={`pointer-events-auto flex items-start gap-2 rounded-lg border px-3 py-2 text-sm shadow-card animate-fade-in ${TONE_STYLES[t.tone]}`}
        >
          <span
            aria-hidden="true"
            className="mt-0.5 inline-flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-current text-[10px] font-bold text-control-950"
          >
            {TONE_ICON[t.tone]}
          </span>
          <p className="flex-1 leading-snug">{t.message}</p>
          <button
            type="button"
            onClick={() =>
              setItems((prev) => prev.filter((x) => x.id !== t.id))
            }
            className="ml-1 text-slate-500 hover:text-slate-200"
            aria-label="Dismiss notification"
          >
            ×
          </button>
        </div>
      ))}
    </div>
  );
}

export default ToastHost;
