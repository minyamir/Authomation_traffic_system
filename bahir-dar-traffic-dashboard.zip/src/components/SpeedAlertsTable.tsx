// src/components/SpeedAlertsTable.tsx
// Optional panel shown when VITE_ENABLE_SPEED="true".
// Labels speed as "estimated" — never presents it as ground truth.

import { useEffect, useState } from "react";
import type { SpeedRow } from "@/types";

interface SpeedAlertsTableProps {
  /** Current recommended speed limit (km/h) for the demo. */
  limit?: number;
  /** Optional seed count for the demo rows. */
  rowCount?: number;
}

function rand(min: number, max: number): number {
  return Math.random() * (max - min) + min;
}

let counter = 0;
function makeRow(limit: number): SpeedRow {
  counter += 1;
  const speed = Math.round(rand(28, 78));
  let status: SpeedRow["status"] = "ok";
  if (speed > limit + 5) status = "over";
  else if (speed > limit) status = "warning";
  return {
    id: `speed-${counter}`,
    time: Date.now(),
    estimatedSpeed: speed,
    limit,
    status,
  };
}

export function SpeedAlertsTable({
  limit = 50,
  rowCount = 6,
}: SpeedAlertsTableProps) {
  const [rows, setRows] = useState<SpeedRow[]>([]);

  useEffect(() => {
    // Seed initial rows.
    setRows(
      Array.from({ length: rowCount }, () => makeRow(limit)).sort(
        (a, b) => b.time - a.time,
      ),
    );
    const id = window.setInterval(() => {
      setRows((prev) => [makeRow(limit), ...prev].slice(0, 12));
    }, 3000);
    return () => window.clearInterval(id);
  }, [limit, rowCount]);

  const STATUS_TONE: Record<SpeedRow["status"], string> = {
    ok: "text-green-300 bg-green-500/10 border border-green-500/30",
    warning: "text-amber-300 bg-amber-400/10 border border-amber-400/30",
    over: "text-red-300 bg-red-500/10 border border-red-500/30",
  };
  const STATUS_LABEL: Record<SpeedRow["status"], string> = {
    ok: "OK",
    warning: "WARNING",
    over: "OVER LIMIT",
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-control-800 text-xs uppercase tracking-wider text-slate-500">
            <th className="py-2 pr-3 font-medium">Time</th>
            <th className="py-2 pr-3 font-medium">Est. speed</th>
            <th className="py-2 pr-3 font-medium">Limit</th>
            <th className="py-2 font-medium">Status</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr
              key={r.id}
              className="border-b border-control-800/60 last:border-0"
            >
              <td className="py-2 pr-3 font-mono text-xs text-slate-400">
                {new Date(r.time).toLocaleTimeString(undefined, {
                  hour12: false,
                })}
              </td>
              <td className="py-2 pr-3 font-mono tabular-nums text-slate-200">
                {r.estimatedSpeed}
                <span className="ml-1 text-xs text-slate-500">km/h</span>
                <span className="ml-1 text-[10px] uppercase tracking-wider text-slate-600">
                  estimated
                </span>
              </td>
              <td className="py-2 pr-3 font-mono tabular-nums text-slate-400">
                {r.limit}
                <span className="ml-1 text-xs text-slate-500">km/h</span>
              </td>
              <td className="py-2">
                <span
                  className={`inline-flex rounded-md px-1.5 py-0.5 text-[10px] font-semibold tracking-wider ${STATUS_TONE[r.status]}`}
                >
                  {STATUS_LABEL[r.status]}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-2 text-[11px] text-slate-500">
        Speed values are <strong>estimated</strong> from the video feed and
        should not be used for enforcement.
      </p>
    </div>
  );
}

export default SpeedAlertsTable;
