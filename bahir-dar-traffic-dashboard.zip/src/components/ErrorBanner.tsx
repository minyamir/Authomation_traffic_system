// src/components/ErrorBanner.tsx
interface ErrorBannerProps {
  title?: string;
  message: string;
  /** Optional retry callback; renders a Retry button when provided. */
  onRetry?: () => void;
  /** Tone — defaults to "error". */
  tone?: "error" | "warning";
}

export function ErrorBanner({
  title = "Something went wrong",
  message,
  onRetry,
  tone = "error",
}: ErrorBannerProps) {
  const palette =
    tone === "error"
      ? "border-red-500/40 bg-red-500/10 text-red-200"
      : "border-amber-400/40 bg-amber-400/10 text-amber-200";
  const btn =
    tone === "error"
      ? "border-red-400/40 text-red-200 hover:bg-red-500/15"
      : "border-amber-400/40 text-amber-200 hover:bg-amber-400/15";
  return (
    <div
      role="alert"
      className={`flex items-start gap-3 rounded-lg border px-3 py-2.5 text-sm ${palette}`}
    >
      <span aria-hidden="true" className="mt-0.5 text-base leading-none">
        !
      </span>
      <div className="min-w-0 flex-1">
        <p className="font-semibold">{title}</p>
        <p className="mt-0.5 text-xs opacity-90">{message}</p>
      </div>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className={`rounded-md border bg-transparent px-2.5 py-1 text-xs font-medium ${btn}`}
        >
          Retry
        </button>
      )}
    </div>
  );
}

export default ErrorBanner;
