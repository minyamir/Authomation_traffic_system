// src/components/CountdownRing.tsx
// Circular countdown showing the recommended green time and seconds elapsed.

interface CountdownRingProps {
  /** Recommended green duration in seconds. */
  total: number;
  /** Seconds elapsed in the current green phase. */
  elapsed: number;
  size?: number;
}

export function CountdownRing({
  total,
  elapsed,
  size = 96,
}: CountdownRingProps) {
  const safeTotal = Math.max(1, total);
  const clampedElapsed = Math.min(Math.max(0, elapsed), safeTotal);
  const ratio = clampedElapsed / safeTotal;
  const remaining = Math.max(0, Math.ceil(safeTotal - clampedElapsed));

  const stroke = 8;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const dash = circumference * (1 - ratio);

  return (
    <div
      className="relative inline-flex items-center justify-center"
      style={{ width: size, height: size }}
      role="img"
      aria-label={`${remaining} of ${safeTotal} seconds of recommended green remaining`}
    >
      <svg
        width={size}
        height={size}
        className="-rotate-90"
        aria-hidden="true"
      >
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="rgb(30,41,59)"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="rgb(34,197,94)"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={dash}
          style={{ transition: "stroke-dashoffset 0.4s linear" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-mono text-2xl font-bold tabular-nums text-green-400">
          {remaining}
        </span>
        <span className="text-[10px] uppercase tracking-widest text-slate-500">
          sec left
        </span>
      </div>
    </div>
  );
}

export default CountdownRing;
