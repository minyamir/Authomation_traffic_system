// src/components/StatCard.tsx
import type { ReactNode } from "react";
import { Skeleton } from "./Skeleton";

interface StatCardProps {
  label: string;
  /** Big value (e.g. "12"). */
  value: ReactNode;
  /** Optional small unit/suffix shown inline (e.g. "s"). */
  unit?: ReactNode;
  /** Optional hint shown under the value. */
  hint?: ReactNode;
  /** Optional icon (top-right). */
  icon?: ReactNode;
  /** Optional accent: small left border + tinted text. */
  accent?: "default" | "green" | "amber" | "red" | "sky";
  loading?: boolean;
  /** Optional aria-label override. */
  ariaLabel?: string;
}

const ACCENT_TEXT: Record<NonNullable<StatCardProps["accent"]>, string> = {
  default: "text-slate-100",
  green: "text-green-400",
  amber: "text-amber-400",
  red: "text-red-400",
  sky: "text-sky-400",
};

const ACCENT_BAR: Record<NonNullable<StatCardProps["accent"]>, string> = {
  default: "bg-control-700",
  green: "bg-green-500",
  amber: "bg-amber-400",
  red: "bg-red-500",
  sky: "bg-sky-500",
};

export function StatCard({
  label,
  value,
  unit,
  hint,
  icon,
  accent = "default",
  loading = false,
  ariaLabel,
}: StatCardProps) {
  return (
    <div
      className="card-base relative overflow-hidden p-4"
      role="group"
      aria-label={ariaLabel ?? label}
    >
      <span
        aria-hidden="true"
        className={`absolute left-0 top-3 bottom-3 w-1 rounded-full ${ACCENT_BAR[accent]}`}
      />
      <div className="flex items-start justify-between">
        <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
          {label}
        </p>
        {icon && <div className="text-slate-500">{icon}</div>}
      </div>
      <div className="mt-2 flex items-baseline gap-1.5">
        {loading ? (
          <Skeleton className="h-9 w-16" label={`${label} loading`} />
        ) : (
          <span
            className={`font-mono text-4xl font-bold tabular-nums leading-none ${ACCENT_TEXT[accent]}`}
          >
            {value}
          </span>
        )}
        {unit && !loading && (
          <span className="text-sm font-medium text-slate-400">{unit}</span>
        )}
      </div>
      {hint && <p className="mt-2 text-xs text-slate-400">{hint}</p>}
    </div>
  );
}

export default StatCard;
