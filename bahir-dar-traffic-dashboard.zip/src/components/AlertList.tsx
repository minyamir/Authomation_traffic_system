// src/components/AlertList.tsx
import type { TrafficAlert } from "@/types";

interface AlertListProps {
  alerts: TrafficAlert[];
  emptyText?: string;
}

const TYPE_STYLES: Record<string, string> = {
  congestion: "bg-red-500/10 text-red-300 border border-red-500/30",
  safety: "bg-amber-400/10 text-amber-300 border border-amber-400/30",
  info: "bg-sky-500/10 text-sky-300 border border-sky-500/30",
  default: "bg-slate-700/40 text-slate-300 border border-slate-600/40",
};

export function AlertList({
  alerts,
  emptyText = "No alerts.",
}: AlertListProps) {
  if (alerts.length === 0) {
    return (
      <div className="flex h-full min-h-[120px] items-center justify-center text-sm text-slate-500">
        {emptyText}
      </div>
    );
  }
  return (
    <ul
      className="max-h-[280px] space-y-1.5 overflow-y-auto pr-1"
      aria-label="Recent alerts"
    >
      {alerts.map((a) => {
        const tone =
          TYPE_STYLES[a.type] ?? TYPE_STYLES.default;
        return (
          <li
            key={a.id}
            className="flex items-start gap-3 rounded-lg border border-control-800 bg-control-950/50 p-2.5 animate-slide-in"
          >
            <span
              className={`mt-0.5 inline-flex shrink-0 items-center rounded-md px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${tone}`}
            >
              {a.type}
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm text-slate-200">{a.message}</p>
              <p className="mt-0.5 font-mono text-[11px] text-slate-500">
                {formatTime(a.time)}
              </p>
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function formatTime(ms: number): string {
  const d = new Date(ms);
  return d.toLocaleTimeString(undefined, {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export default AlertList;
