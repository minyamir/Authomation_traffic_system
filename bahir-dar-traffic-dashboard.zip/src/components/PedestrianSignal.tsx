// src/components/PedestrianSignal.tsx
import type { PedestrianSignal as PS } from "@/types";

interface PedestrianSignalProps {
  signal: PS;
}

export function PedestrianSignal({ signal }: PedestrianSignalProps) {
  const isWalk = signal === "walk";
  const label = isWalk ? "WALK" : "WAIT";
  const tone = isWalk ? "green" : "red";

  return (
    <div className="flex items-center gap-4">
      <div
        className="rounded-2xl border border-control-800 bg-control-950 p-3"
        role="img"
        aria-label={`Pedestrian signal: ${signal} (${label})`}
      >
        <div
          aria-hidden="true"
          className={`flex h-16 w-16 items-center justify-center rounded-full transition-all duration-200 ${
            isWalk
              ? "bg-green-500 shadow-[0_0_18px_4px_rgba(34,197,94,0.7)]"
              : "bg-red-500 shadow-[0_0_18px_4px_rgba(239,68,68,0.7)]"
          }`}
        >
          {isWalk ? <WalkIcon /> : <WaitIcon />}
        </div>
      </div>
      <div>
        <span
          className={`text-xs font-semibold tracking-widest ${
            isWalk ? "text-green-300" : "text-red-300"
          }`}
        >
          {label}
        </span>
        <p className="mt-1 max-w-[10rem] text-xs text-slate-400">
          {isWalk
            ? "Pedestrians may cross."
            : "Pedestrians must wait on the curb."}
        </p>
        <span className="sr-only" data-tone={tone}>
          {tone}
        </span>
      </div>
    </div>
  );
}

function WalkIcon() {
  // Walking figure (simple geometric body in motion)
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-9 w-9 text-control-950"
      fill="currentColor"
      aria-hidden="true"
    >
      <circle cx="13" cy="4" r="2" />
      <path d="M13.5 8c.8 0 1.5.5 1.8 1.2l1.4 3.3c.2.5 0 1.1-.5 1.3-.5.2-1.1 0-1.3-.5l-1-2.3-1.4 1.6 1.8 2.4c.3.4.3.9 0 1.3l-2 3.2c-.3.5-.9.6-1.4.3-.5-.3-.6-.9-.3-1.4l1.7-2.7-1.6-2.1c-.5-.7-.4-1.6.1-2.2l1.7-1.9z" />
    </svg>
  );
}

function WaitIcon() {
  // Raised hand (palm) silhouette
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-9 w-9 text-control-950"
      fill="currentColor"
      aria-hidden="true"
    >
      <path d="M9 11V5.5a1.5 1.5 0 1 1 3 0V10h.5V4.5a1.5 1.5 0 0 1 3 0V11h.5V6.5a1.5 1.5 0 0 1 3 0v7c0 3.3-2.5 6-5.8 6-2.6 0-4.4-1.3-5.5-3.2L6 13.7c-.5-.9-.2-2 .7-2.5.8-.4 1.8-.2 2.3.6L9 12z" />
    </svg>
  );
}

export default PedestrianSignal;
