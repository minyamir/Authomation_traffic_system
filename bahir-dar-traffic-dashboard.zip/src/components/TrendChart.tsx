// src/components/TrendChart.tsx
// Recharts-based trend chart of vehicle & pedestrian counts over the last 60 samples.

import { useMemo } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { TrafficState } from "@/types";

interface TrendChartProps {
  history: TrafficState[];
}

interface Point {
  t: string;
  vehicles: number;
  pedestrians: number;
}

export function TrendChart({ history }: TrendChartProps) {
  const data = useMemo<Point[]>(() => {
    return history.map((s) => ({
      t: new Date(s.timestamp).toLocaleTimeString(undefined, {
        hour12: false,
        minute: "2-digit",
        second: "2-digit",
      }),
      vehicles: s.vehicleCount,
      pedestrians: s.pedestrianCount,
    }));
  }, [history]);

  if (data.length === 0) {
    return (
      <div className="flex h-[220px] items-center justify-center text-sm text-slate-500">
        Waiting for samples…
      </div>
    );
  }

  return (
    <div className="h-[240px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{ top: 8, right: 16, bottom: 0, left: -12 }}
        >
          <CartesianGrid
            strokeDasharray="3 3"
            stroke="rgb(30,41,59)"
            vertical={false}
          />
          <XAxis
            dataKey="t"
            stroke="rgb(100,116,139)"
            tick={{ fill: "rgb(148,163,184)", fontSize: 10 }}
            tickLine={false}
            axisLine={{ stroke: "rgb(30,41,59)" }}
            minTickGap={24}
          />
          <YAxis
            stroke="rgb(100,116,139)"
            tick={{ fill: "rgb(148,163,184)", fontSize: 10 }}
            tickLine={false}
            axisLine={{ stroke: "rgb(30,41,59)" }}
            allowDecimals={false}
            width={36}
          />
          <Tooltip
            cursor={{ stroke: "rgb(71,85,105)", strokeDasharray: "3 3" }}
            contentStyle={{
              backgroundColor: "rgb(15,23,42)",
              border: "1px solid rgb(30,41,59)",
              borderRadius: 8,
              color: "rgb(226,232,240)",
              fontSize: 12,
            }}
            labelStyle={{ color: "rgb(148,163,184)" }}
            formatter={(value: number, name) => {
              const label = name === "vehicles" ? "Vehicles" : "Pedestrians";
              return [value, label];
            }}
          />
          <Line
            type="monotone"
            dataKey="vehicles"
            stroke="rgb(56,189,248)"
            strokeWidth={2}
            dot={false}
            isAnimationActive={false}
            name="vehicles"
          />
          <Line
            type="monotone"
            dataKey="pedestrians"
            stroke="rgb(34,197,94)"
            strokeWidth={2}
            dot={false}
            isAnimationActive={false}
            name="pedestrians"
          />
        </LineChart>
      </ResponsiveContainer>
      <div className="mt-1 flex items-center justify-center gap-4 text-xs text-slate-400">
        <Legend color="bg-sky-400" label="Vehicles" />
        <Legend color="bg-green-500" label="Pedestrians" />
      </div>
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span aria-hidden="true" className={`h-2 w-2 rounded-full ${color}`} />
      {label}
    </span>
  );
}

export default TrendChart;
