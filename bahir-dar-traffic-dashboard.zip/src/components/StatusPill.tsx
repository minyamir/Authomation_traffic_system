// src/components/StatusPill.tsx
import type { StreamStatus } from "@/types";

interface StatusPillProps {
  status: StreamStatus;
  isMock?: boolean;
  error?: string;
}

const LABELS: Record<StreamStatus, string> = {
  connecting: "Connecting",
  live: "Live",
  offline: "Offline",
};

const DOT_CLASS: Record<StreamStatus, string> = {
  connecting: "bg-amber-400 animate-pulse-soft",
  live: "bg-green-500",
  offline: "bg-red-500",
};

const PILL_CLASS: Record<StreamStatus, string> = {
  connecting:
    "bg-amber-400/10 text-amber-300 border border-amber-400/30",
  live: "bg-green-500/10 text-green-300 border border-green-500/30",
  offline: "bg-red-500/10 text-red-300 border border-red-500/30",
};

export function StatusPill({ status, isMock = false, error }: StatusPillProps) {
  const label = isMock && status === "live" ? "Mock" : LABELS[status];
  const title = isMock
    ? "Running on in-browser mock data"
    : error
      ? error
      : `Stream ${status}`;
  return (
    <span
      className={`pill-base ${PILL_CLASS[status]}`}
      role="status"
      aria-live="polite"
      title={title}
    >
      <span aria-hidden="true" className={`h-1.5 w-1.5 rounded-full ${DOT_CLASS[status]}`} />
      <span className="font-semibold tracking-wide">{label}</span>
    </span>
  );
}

export default StatusPill;
