// src/components/VideoPanel.tsx
// Large video panel: drag-and-drop upload box above a <video> element.
// Shows empty state when no clip has been uploaded yet.

import { useCallback, useEffect, useRef, useState } from "react";
import { Card } from "./Card";
import { UploadBox } from "./UploadBox";
import { USE_MOCK } from "@/api/client";

interface VideoPanelProps {
  /** Notifies parent when a video has been uploaded + preview URL is ready. */
  onVideoReady?: (previewUrl: string) => void;
}

export function VideoPanel({ onVideoReady }: VideoPanelProps) {
  const [videoUrl, setVideoUrl] = useState<string>("");
  const [fileName, setFileName] = useState<string>("");
  const [muted, setMuted] = useState<boolean>(true);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    return () => {
      if (videoUrl) URL.revokeObjectURL(videoUrl);
    };
  }, [videoUrl]);

  const handleUploaded = useCallback(
    (_file: File, _result: unknown, previewUrl: string) => {
      setVideoUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev);
        return previewUrl;
      });
      setFileName(_file.name);
      onVideoReady?.(previewUrl);
      // Try to autoplay.
      requestAnimationFrame(() => {
        videoRef.current?.play().catch(() => {
          // Autoplay blocked; user will press play.
        });
      });
    },
    [onVideoReady],
  );

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      const next = !m;
      if (videoRef.current) videoRef.current.muted = next;
      return next;
    });
  }, []);

  return (
    <Card
      title="Live Traffic Feed"
      subtitle={
        fileName ? `Playing: ${fileName}` : "Upload a clip to begin analysis"
      }
      action={
        videoUrl ? (
          <span className="pill-base border border-green-500/30 bg-green-500/10 text-green-300">
            <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse-soft" />
            Streaming
          </span>
        ) : (
          <span
            className="pill-base border border-control-700 bg-control-800 text-slate-400"
            title="No video uploaded yet"
          >
            <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-slate-500" />
            Idle
          </span>
        )
      }
      padded={false}
      bodyClassName="p-4"
    >
      <UploadBox onUploaded={handleUploaded} simulateInMock={USE_MOCK} />

      <div className="mt-4">
        {videoUrl ? (
          <div className="relative overflow-hidden rounded-lg border border-control-800 bg-black">
            <video
              ref={videoRef}
              src={videoUrl}
              controls
              muted={muted}
              loop
              playsInline
              className="aspect-video w-full bg-black"
              aria-label={`Uploaded traffic video: ${fileName}`}
            />
            <button
              type="button"
              onClick={toggleMute}
              className="absolute bottom-2 right-2 rounded-md border border-control-700 bg-control-900/80 px-2 py-1 text-xs text-slate-200 backdrop-blur hover:bg-control-800"
              aria-pressed={!muted}
            >
              {muted ? "Unmute" : "Mute"}
            </button>
          </div>
        ) : (
          <div
            className="flex aspect-video w-full flex-col items-center justify-center rounded-lg border border-control-800 bg-control-950/40 text-center"
            aria-label="No video uploaded yet"
          >
            <VideoIcon />
            <p className="mt-3 text-sm text-slate-300">
              Upload a traffic clip to begin.
            </p>
            <p className="mt-1 max-w-sm text-xs text-slate-500">
              The dashboard will overlay the live signal state alongside your video.
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}

function VideoIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-10 w-10 text-slate-600"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.4"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <rect x="3" y="6" width="13" height="12" rx="2" />
      <path d="m16 10 5-3v10l-5-3z" />
    </svg>
  );
}

export default VideoPanel;
