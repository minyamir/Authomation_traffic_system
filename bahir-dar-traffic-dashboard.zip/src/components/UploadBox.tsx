// src/components/UploadBox.tsx
import { useCallback, useEffect, useRef, useState } from "react";
import type { UploadStatus } from "@/types";
import { uploadFile } from "@/api/client";
import { ENDPOINT_UPLOAD_VIDEO } from "@/api/endpoints";

interface UploadResult {
  id?: string;
  url?: string;
  [k: string]: unknown;
}

interface UploadBoxProps {
  onUploaded: (file: File, result: UploadResult, previewUrl: string) => void;
  /** When true (mock mode), the upload is simulated locally. */
  simulateInMock?: boolean;
}

const ACCEPTED = ["video/mp4", "video/quicktime", "video/webm", "video/x-matroska"];

export function UploadBox({ onUploaded, simulateInMock = true }: UploadBoxProps) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [status, setStatus] = useState<UploadStatus>("idle");
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string>("");
  const [dragging, setDragging] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
    };
  }, []);

  const startUpload = useCallback(
    async (file: File) => {
      setError("");
      setStatus("uploading");
      setProgress(0);

      // Mock mode: simulate progress locally so the demo flows even without a backend.
      if (simulateInMock) {
        const totalMs = 1500;
        const startedAt = performance.now();
        await new Promise<void>((resolve) => {
          const tick = () => {
            const elapsed = performance.now() - startedAt;
            const r = Math.min(1, elapsed / totalMs);
            setProgress(r);
            if (r < 1) {
              requestAnimationFrame(tick);
            } else {
              resolve();
            }
          };
          requestAnimationFrame(tick);
        });
        const previewUrl = URL.createObjectURL(file);
        setStatus("success");
        setProgress(1);
        onUploaded(file, { id: `mock-${Date.now()}`, url: previewUrl }, previewUrl);
        return;
      }

      const controller = new AbortController();
      abortRef.current = controller;
      try {
        const result = await uploadFile(
          ENDPOINT_UPLOAD_VIDEO,
          file,
          (_loaded, _total, ratio) => setProgress(ratio),
          controller.signal,
        );
        const previewUrl = URL.createObjectURL(file);
        setStatus("success");
        setProgress(1);
        onUploaded(file, result as UploadResult, previewUrl);
      } catch (err) {
        const msg =
          err instanceof Error ? err.message : "Upload failed";
        setError(msg);
        setStatus("error");
      }
    },
    [onUploaded, simulateInMock],
  );

  const handleFiles = useCallback(
    (files: FileList | null) => {
      if (!files || files.length === 0) return;
      const file = files[0];
      if (!file.type.startsWith("video/") && !ACCEPTED.includes(file.type)) {
        setError("Please drop a video file (mp4, mov, webm, mkv).");
        setStatus("error");
        return;
      }
      void startUpload(file);
    },
    [startUpload],
  );

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(true);
  }, []);

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(false);
  }, []);

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setDragging(false);
      if (status === "uploading") return;
      handleFiles(e.dataTransfer.files);
    },
    [handleFiles, status],
  );

  const onPick = useCallback(() => {
    inputRef.current?.click();
  }, []);

  const onInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      handleFiles(e.target.files);
      // Allow re-uploading the same file
      e.target.value = "";
    },
    [handleFiles],
  );

  const onCancel = useCallback(() => {
    abortRef.current?.abort();
    setStatus("idle");
    setProgress(0);
  }, []);

  return (
    <div>
      <div
        role="button"
        tabIndex={0}
        aria-label="Upload a traffic video clip"
        onClick={onPick}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            onPick();
          }
        }}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
        className={`flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed px-4 py-5 text-center transition-colors ${
          dragging
            ? "border-sky-400 bg-sky-500/5"
            : "border-control-700 hover:border-slate-500 hover:bg-control-800/40"
        } ${status === "uploading" ? "pointer-events-none opacity-70" : ""}`}
      >
        <UploadIcon />
        <p className="mt-2 text-sm font-medium text-slate-200">
          {dragging ? "Drop the video here" : "Drag & drop a traffic clip"}
        </p>
        <p className="mt-0.5 text-xs text-slate-500">
          or click to browse · mp4, mov, webm, mkv
        </p>
        <input
          ref={inputRef}
          type="file"
          accept="video/*"
          className="sr-only"
          onChange={onInputChange}
        />
      </div>

      {status === "uploading" && (
        <div className="mt-3" aria-live="polite">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Uploading…</span>
            <span className="font-mono tabular-nums">
              {Math.round(progress * 100)}%
            </span>
          </div>
          <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-control-800">
            <div
              className="h-full rounded-full bg-sky-500 transition-[width] duration-200"
              style={{ width: `${Math.round(progress * 100)}%` }}
            />
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="mt-2 text-xs font-medium text-slate-400 underline-offset-2 hover:text-red-300 hover:underline"
          >
            Cancel upload
          </button>
        </div>
      )}

      {status === "error" && (
        <p
          role="alert"
          className="mt-3 rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-300"
        >
          {error}
        </p>
      )}
    </div>
  );
}

function UploadIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-7 w-7 text-slate-400"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M12 16V4" />
      <path d="m7 9 5-5 5 5" />
      <path d="M5 20h14" />
    </svg>
  );
}

export default UploadBox;
