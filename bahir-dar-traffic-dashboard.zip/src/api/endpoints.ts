// src/api/endpoints.ts
//
// ─────────────────────────────────────────────────────────────────────────────
// TODO confirm with backend.
// All backend endpoints live in this one file so they can be changed in a
// single place once the FastAPI routes are confirmed. Do NOT hard-code these
// URLs anywhere else in the codebase — import from here.
// ─────────────────────────────────────────────────────────────────────────────
//
// Endpoints assumed (subject to backend confirmation):
//   POST /videos        multipart/form-data, field name "file"  -> { id, url, ... }
//   GET  /health                                            -> { status: "ok" }
//   WS   /ws                                               -> streams TrafficState JSON
//   POST /report           body: TrafficState                -> { report: string }
//
// No authentication is required for any endpoint (hackathon demo).

import { apiUrl } from "./client";

/** REST: upload a traffic video clip. Multipart field name is "file". */
export const ENDPOINT_UPLOAD_VIDEO = "/videos";

/** REST: backend liveness probe. */
export const ENDPOINT_HEALTH = "/health";

/** REST: ask the backend to generate an AI traffic report from a state. */
export const ENDPOINT_REPORT = "/report";

/** Build the absolute WebSocket URL for the live traffic stream. */
export function wsStreamUrl(wsBase?: string): string {
  // If a full ws(s):// URL is supplied via env, use it directly.
  const fromEnv = (import.meta.env.VITE_WS_URL as string | undefined)?.trim();
  if (fromEnv) return fromEnv;
  if (wsBase) return wsBase;
  // Otherwise derive ws:// from the REST base URL.
  const base = apiUrl("");
  return base.replace(/^http/i, "ws") + "ws";
}

/** Absolute URL for a given REST path (prefixed with VITE_API_URL). */
export function restUrl(path: string): string {
  return apiUrl(path);
}
