// src/api/mock.ts
//
// In-browser mock traffic-state emitter.
// Emits a fresh TrafficState every second, cycling realistically through:
//   vehicle green -> yellow -> all-red -> pedestrian walk -> back to green
//
// The frontend NEVER computes signal logic; this mock just simulates the
// backend's output so the dashboard is demoable without a server.

import type {
  Congestion,
  TrafficAlert,
  TrafficState,
  VehicleLight,
  PedestrianSignal,
} from "@/types";

type PhaseSpec = {
  /** Approx duration in seconds at 1 emit/sec. */
  duration: number;
  vehicleLight: VehicleLight;
  pedestrianSignal: PedestrianSignal;
};

// Full cycle ~ 32 seconds.
const PHASES: PhaseSpec[] = [
  { duration: 14, vehicleLight: "green", pedestrianSignal: "wait" },
  { duration: 3, vehicleLight: "yellow", pedestrianSignal: "wait" },
  { duration: 2, vehicleLight: "red", pedestrianSignal: "wait" },
  { duration: 10, vehicleLight: "red", pedestrianSignal: "walk" },
  { duration: 3, vehicleLight: "red", pedestrianSignal: "wait" },
];

let idCounter = 0;
function nextId(prefix: string): string {
  idCounter += 1;
  return `${prefix}-${idCounter}-${Math.random().toString(36).slice(2, 7)}`;
}

interface MockOptions {
  /** Initial seed for vehicle/pedestrian counts. */
  baseVehicles?: number;
  basePedestrians?: number;
}

export class MockTrafficStream {
  private listeners = new Set<(s: TrafficState) => void>();
  private timer: ReturnType<typeof setInterval> | null = null;
  private phaseIdx = 0;
  private phaseTick = 0;
  private cycleTick = 0;
  private vehicles: number;
  private pedestrians: number;
  private congestion: Congestion = "low";
  private recommendedGreen = 14;
  private alerts: TrafficAlert[] = [];
  private lastCongestionAlert = 0;

  constructor(opts: MockOptions = {}) {
    this.vehicles = opts.baseVehicles ?? 8;
    this.pedestrians = opts.basePedestrians ?? 2;
  }

  subscribe(fn: (s: TrafficState) => void): () => void {
    this.listeners.add(fn);
    // Emit one immediately so subscribers don't wait.
    fn(this.snapshot());
    if (!this.timer) this.start();
    return () => {
      this.listeners.delete(fn);
      if (this.listeners.size === 0) this.stop();
    };
  }

  private start(): void {
    this.timer = setInterval(() => this.tick(), 1000);
  }

  private stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private currentPhase(): PhaseSpec {
    return PHASES[this.phaseIdx];
  }

  private advancePhase(): void {
    this.phaseIdx = (this.phaseIdx + 1) % PHASES.length;
    this.phaseTick = 0;
    const phase = this.currentPhase();
    if (phase.vehicleLight === "green" && phase.pedestrianSignal === "wait") {
      // Just entered a new vehicle-green cycle.
      this.maybeAdjustCongestion();
    }
  }

  private maybeAdjustCongestion(): void {
    // Random walk on congestion.
    const roll = Math.random();
    if (this.congestion === "low") {
      if (roll < 0.25) this.congestion = "medium";
    } else if (this.congestion === "medium") {
      if (roll < 0.2) this.congestion = "high";
      else if (roll < 0.4) this.congestion = "low";
    } else {
      if (roll < 0.35) this.congestion = "medium";
    }
    // Recommended green scales with congestion.
    this.recommendedGreen =
      this.congestion === "high"
        ? 22
        : this.congestion === "medium"
          ? 16
          : 12;
  }

  private tick(): void {
    this.cycleTick += 1;
    this.phaseTick += 1;
    const phase = this.currentPhase();

    // Drift counts in a believable way.
    if (phase.vehicleLight === "green") {
      // Vehicles leaving the intersection.
      this.vehicles = Math.max(0, this.vehicles - (Math.random() < 0.6 ? 1 : 0));
      // Some new arrivals.
      if (Math.random() < 0.5) this.vehicles += 1;
    } else if (phase.vehicleLight === "red") {
      // Vehicles accumulate while waiting.
      if (Math.random() < 0.7) this.vehicles += 1;
    }
    if (phase.pedestrianSignal === "walk") {
      this.pedestrians = Math.max(
        0,
        this.pedestrians - (Math.random() < 0.5 ? 1 : 0),
      );
      if (Math.random() < 0.3) this.pedestrians += 1;
    } else {
      if (Math.random() < 0.15) this.pedestrians += 1;
    }

    // Hard cap to keep numbers readable.
    if (this.vehicles > 40) this.vehicles = 40;
    if (this.pedestrians > 15) this.pedestrians = 15;

    // Emit congestion alerts (throttled).
    const now = Date.now();
    if (
      this.congestion === "high" &&
      now - this.lastCongestionAlert > 8_000
    ) {
      this.lastCongestionAlert = now;
      this.pushAlert({
        type: "congestion",
        message: `High congestion detected — ${this.vehicles} vehicles queued`,
      });
    }
    if (phase.vehicleLight === "yellow" && this.phaseTick === 1) {
      this.pushAlert({
        type: "info",
        message: "Vehicle signal transitioning to yellow",
      });
    }
    if (phase.pedestrianSignal === "walk" && this.phaseTick === 1) {
      this.pushAlert({
        type: "safety",
        message: "Pedestrian walk phase active",
      });
    }

    if (this.phaseTick >= phase.duration) this.advancePhase();

    this.emit(this.snapshot());
  }

  private pushAlert(a: Omit<TrafficAlert, "id" | "time">): void {
    const alert: TrafficAlert = { id: nextId(a.type), time: Date.now(), ...a };
    this.alerts = [alert, ...this.alerts].slice(0, 30);
  }

  private snapshot(): TrafficState {
    const phase = this.currentPhase();
    return {
      timestamp: Date.now(),
      vehicleCount: this.vehicles,
      pedestrianCount: this.pedestrians,
      congestion: this.congestion,
      recommendedGreenSeconds: this.recommendedGreen,
      vehicleLight: phase.vehicleLight,
      pedestrianSignal: phase.pedestrianSignal,
      alerts: this.alerts.slice(0, 12),
    };
  }

  private emit(s: TrafficState): void {
    this.listeners.forEach((fn) => fn(s));
  }
}

/** Shared singleton — all hook instances subscribe to the same source. */
let singleton: MockTrafficStream | null = null;
export function getMockStream(): MockTrafficStream {
  if (!singleton) singleton = new MockTrafficStream();
  return singleton;
}

/** Generate a fake AI traffic report (used by VITE_ENABLE_REPORT in mock mode). */
export function mockGenerateReport(state: TrafficState): string {
  const lines = [
    "AI TRAFFIC REPORT — Bahir Dar Intersection",
    `Generated: ${new Date(state.timestamp).toLocaleString()}`,
    "",
    "1. CURRENT OBSERVATIONS",
    `   • Vehicles detected: ${state.vehicleCount}`,
    `   • Pedestrians waiting: ${state.pedestrianCount}`,
    `   • Congestion level: ${state.congestion.toUpperCase()}`,
    `   • Vehicle signal: ${state.vehicleLight.toUpperCase()}`,
    `   • Pedestrian signal: ${state.pedestrianSignal.toUpperCase()}`,
    "",
    "2. SIGNAL TIMING RECOMMENDATION",
    `   • Recommended green duration: ${state.recommendedGreenSeconds}s`,
    `   • Rationale: ${reportRationale(state)}`,
    "",
    "3. SAFETY CHECK",
    `   • ${safetySummary(state)}`,
    "",
    "4. ADVISORY",
    `   • ${advisory(state)}`,
    "",
    "— End of report —",
  ];
  return lines.join("\n");
}

function reportRationale(state: TrafficState): string {
  if (state.congestion === "high")
    return "Queue length is elevated; extended green clears the backlog.";
  if (state.congestion === "medium")
    return "Moderate queue; standard green with slight extension.";
  return "Light traffic; minimum green suffices for fairness.";
}

function safetySummary(state: TrafficState): string {
  const conflict = state.vehicleLight === "green" && state.pedestrianSignal === "walk";
  if (conflict)
    return "WARNING — conflicting signal state detected (vehicle green + pedestrian walk).";
  return "No conflicting signal states detected.";
}

function advisory(state: TrafficState): string {
  if (state.congestion === "high")
    return "Consider rerouting non-essential vehicles and enabling adaptive timing.";
  if (state.pedestrianCount > 6)
    return "High pedestrian activity — extend next walk phase by 2s.";
  return "Operations nominal; maintain current timing plan.";
}
