// src/api/client.ts
//
// Thin fetch wrapper for the FastAPI backend.
// - Base URL comes from VITE_API_URL (falls back to http://localhost:8000).
// - VITE_USE_MOCK gates whether the rest of the app should prefer the mock.
// - No auth (hackathon demo).

export const API_BASE_URL: string =
  (import.meta.env.VITE_API_URL as string | undefined)?.replace(/\/$/, "") ||
  "http://localhost:8000";

export const USE_MOCK: boolean =
  String(import.meta.env.VITE_USE_MOCK ?? "true").toLowerCase() === "true";

export const ENABLE_REPORT: boolean =
  String(import.meta.env.VITE_ENABLE_REPORT ?? "false").toLowerCase() === "true";

export const ENABLE_SPEED: boolean =
  String(import.meta.env.VITE_ENABLE_SPEED ?? "false").toLowerCase() === "true";

export const ENABLE_PLATES: boolean =
  String(import.meta.env.VITE_ENABLE_PLATES ?? "false").toLowerCase() === "true";

/** Build an absolute URL by joining the API base with a path. */
export function apiUrl(path: string): string {
  if (/^https?:\/\//i.test(path)) return path;
  const clean = path.startsWith("/") ? path : `/${path}`;
  return `${API_BASE_URL}${clean}`;
}

export class ApiError extends Error {
  status: number;
  body?: unknown;
  constructor(message: string, status: number, body?: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.body = body;
  }
}

interface FetchOptions extends RequestInit {
  /** Parsed JSON return type. Throws ApiError on non-2xx. */
  json?: boolean;
}

/** Wraps fetch with consistent error handling and JSON parsing. */
export async function apiFetch<T = unknown>(
  path: string,
  opts: FetchOptions = {},
): Promise<T> {
  const { json = true, headers, ...rest } = opts;
  let res: Response;
  try {
    res = await fetch(apiUrl(path), {
      headers: { Accept: "application/json", ...(headers ?? {}) },
      ...rest,
    });
  } catch (err) {
    throw new ApiError(
      err instanceof Error ? err.message : "Network request failed",
      0,
    );
  }

  if (!res.ok) {
    let body: unknown;
    try {
      body = await res.clone().json();
    } catch {
      try {
        body = await res.text();
      } catch {
        body = undefined;
      }
    }
    throw new ApiError(
      `Request failed: ${res.status} ${res.statusText}`,
      res.status,
      body,
    );
  }

  if (!json) return undefined as T;
  // 204 No Content
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

/** POST JSON helper. */
export function postJson<T = unknown>(path: string, body: unknown): Promise<T> {
  return apiFetch<T>(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

/**
 * Upload a file with multipart/form-data and progress events.
 * Field name is "file" (see endpoints.ts).
 */
export function uploadFile(
  path: string,
  file: File,
  onProgress?: (loaded: number, total: number, ratio: number) => void,
  signal?: AbortSignal,
): Promise<{ id?: string; url?: string; [k: string]: unknown }> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", apiUrl(path));
    xhr.responseType = "json";

    xhr.upload.onprogress = (e) => {
      if (!e.lengthComputable) return;
      onProgress?.(e.loaded, e.total, e.loaded / e.total);
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        const data =
          typeof xhr.response === "string"
            ? safeJson(xhr.response)
            : xhr.response;
        resolve(data ?? {});
      } else {
        reject(
          new ApiError(
            `Upload failed: ${xhr.status} ${xhr.statusText}`,
            xhr.status,
            xhr.response,
          ),
        );
      }
    };

    xhr.onerror = () =>
      reject(new ApiError("Network error during upload", 0));
    xhr.onabort = () => reject(new ApiError("Upload aborted", 0));

    if (signal) {
      if (signal.aborted) xhr.abort();
      signal.addEventListener("abort", () => xhr.abort(), { once: true });
    }

    const form = new FormData();
    form.append("file", file);
    xhr.send(form);
  });
}

function safeJson(s: string): unknown {
  try {
    return JSON.parse(s);
  } catch {
    return { raw: s };
  }
}
