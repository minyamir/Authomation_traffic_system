// src/App.tsx
// Bahir Dar AI Traffic Management — hackathon demo dashboard.
// Displays FastAPI traffic-video analysis output. The frontend only DISPLAYS
// backend data; it never computes signal logic itself.

import { useEffect, useMemo, useRef, useState } from "react";
import { useTrafficStream } from "@/hooks/useTrafficStream";
import { USE_MOCK, ENABLE_REPORT, ENABLE_SPEED, ENABLE_PLATES } from "@/api/client";
import { Card } from "@/components/Card";
import { StatusPill } from "@/components/StatusPill";
import { StatCard } from "@/components/StatCard";
import { CongestionBadge } from "@/components/CongestionBadge";
import { TrafficLight } from "@/components/TrafficLight";
import { PedestrianSignal } from "@/components/PedestrianSignal";
import { CountdownRing } from "@/components/CountdownRing";
import { TrendChart } from "@/components/TrendChart";
import { AlertList } from "@/components/AlertList";
import { VideoPanel } from "@/components/VideoPanel";
import { ReportCard } from "@/components/ReportCard";
import { SpeedAlertsTable } from "@/components/SpeedAlertsTable";
import { ErrorBanner } from "@/components/ErrorBanner";
import { Skeleton } from "@/components/Skeleton";
import { ToastHost } from "@/components/Toast";

export default function App() {
  const { state, history, status, isMock, error } = useTrafficStream();

  // Track the time we entered the current vehicle-green phase so the
  // countdown ring can show elapsed seconds (display only — no logic).
  const greenPhaseStart = useRef<number | null>(null);
  const [secondsElapsed, setSecondsElapsed] = useState<number>(0);

  useEffect(() => {
    if (!state) return;
    if (state.vehicleLight === "green") {
      if (greenPhaseStart.current === null) {
        greenPhaseStart.current = state.timestamp;
      }
      const elapsed = Math.floor(
        (state.timestamp - greenPhaseStart.current) / 1000,
      );
      setSecondsElapsed(elapsed);
    } else {
      greenPhaseStart.current = null;
      setSecondsElapsed(0);
    }
  }, [state]);

  // SAFETY: detect conflicting signal state (vehicle green + pedestrian walk).
  const conflicting = useMemo(() => {
    if (!state) return false;
    return state.vehicleLight === "green" && state.pedestrianSignal === "walk";
  }, [state]);

  const connecting = status === "connecting" && !state;

  return (
    <div className="min-h-full">
      <ToastHost />
      <Header status={status} isMock={isMock} />

      <main className="mx-auto max-w-[1600px] px-4 pb-12 sm:px-6 lg:px-8">
        {conflicting && (
          <div className="mb-4">
            <ErrorBanner
              tone="error"
              title="Conflicting signal state"
              message="Vehicle light is GREEN while pedestrian signal is WALK. The signal panel below is hidden until the conflict clears."
            />
          </div>
        )}

        {status === "offline" && !USE_MOCK && (
          <div className="mb-4">
            <ErrorBanner
              tone="warning"
              title="Backend stream offline"
              message={
                error ||
                "WebSocket connection lost. Reconnecting automatically…"
              }
            />
          </div>
        )}

        <div className="grid grid-cols-12 gap-4">
          {/* ─── Row 1: video (large) + stat column ─────────────────────── */}
          <div className="col-span-12 xl:col-span-8">
            <VideoPanel />
          </div>
          <div className="col-span-12 grid grid-cols-2 gap-4 xl:col-span-4">
            {connecting ? (
              <>
                <SkeletonStat />
                <SkeletonStat />
                <SkeletonStat />
                <SkeletonStat />
              </>
            ) : (
              <>
                <StatCard
                  label="Vehicles"
                  value={state?.vehicleCount ?? 0}
                  accent="sky"
                  icon={<CarIcon />}
                  loading={!state}
                  hint="Detected in current frame"
                />
                <StatCard
                  label="Pedestrians"
                  value={state?.pedestrianCount ?? 0}
                  accent="green"
                  icon={<PersonIcon />}
                  loading={!state}
                  hint="At the crossing"
                />
                <div className="card-base flex flex-col justify-between p-4">
                  <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
                    Congestion
                  </p>
                  <div className="mt-3">
                    {state ? (
                      <CongestionBadge level={state.congestion} />
                    ) : (
                      <Skeleton className="h-7 w-24" />
                    )}
                  </div>
                  <p className="mt-3 text-xs text-slate-500">
                    {state?.congestion === "high"
                      ? "Queues forming — extended green advised."
                      : state?.congestion === "medium"
                        ? "Moderate flow."
                        : "Flow is nominal."}
                  </p>
                </div>
                <div className="card-base flex items-center justify-between p-4">
                  <div className="flex flex-col">
                    <p className="text-xs font-medium uppercase tracking-wider text-slate-400">
                      Recommended green
                    </p>
                    <div className="mt-2 flex items-baseline gap-1">
                      <span className="font-mono text-4xl font-bold tabular-nums text-green-400">
                        {state?.recommendedGreenSeconds ?? 0}
                      </span>
                      <span className="text-sm text-slate-400">s</span>
                    </div>
                    <p className="mt-2 text-xs text-slate-500">
                      AI-recommended phase length
                    </p>
                  </div>
                  {state && (
                    <CountdownRing
                      total={state.recommendedGreenSeconds}
                      elapsed={secondsElapsed}
                    />
                  )}
                </div>
              </>
            )}
          </div>

          {/* ─── Row 2: signal panel + trend chart ──────────────────────── */}
          <div className="col-span-12 xl:col-span-5">
            <Card
              title="Signal Panel"
              subtitle="Vehicle & pedestrian signals (display only)"
              action={
                state && (
                  <span className="font-mono text-xs text-slate-500">
                    {formatClock(state.timestamp)}
                  </span>
                )
              }
            >
              {connecting ? (
                <div className="space-y-3">
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-24 w-full" />
                </div>
              ) : conflicting ? (
                <div
                  role="alert"
                  className="flex h-full min-h-[200px] flex-col items-center justify-center rounded-lg border border-red-500/40 bg-red-500/5 p-4 text-center"
                >
                  <WarnIcon />
                  <p className="mt-2 text-sm font-semibold text-red-300">
                    Signal panel hidden — conflicting state
                  </p>
                  <p className="mt-1 text-xs text-slate-400">
                    Vehicle GREEN + pedestrian WALK is unsafe. Panel will
                    return when the conflict clears.
                  </p>
                </div>
              ) : state ? (
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <div>
                    <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
                      Vehicle signal
                    </h3>
                    <TrafficLight
                      light={state.vehicleLight}
                      secondsRemaining={
                        state.vehicleLight === "green"
                          ? Math.max(
                              0,
                              state.recommendedGreenSeconds - secondsElapsed,
                            )
                          : undefined
                      }
                    />
                  </div>
                  <div>
                    <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
                      Pedestrian signal
                    </h3>
                    <PedestrianSignal signal={state.pedestrianSignal} />
                  </div>
                </div>
              ) : (
                <div className="flex h-full min-h-[120px] items-center justify-center text-sm text-slate-500">
                  Waiting for signal state…
                </div>
              )}
            </Card>
          </div>

          <div className="col-span-12 xl:col-span-7">
            <Card
              title="Vehicle & Pedestrian Trend"
              subtitle="Last 60 samples"
              action={
                <span className="pill-base border border-control-700 bg-control-800 text-slate-300">
                  {history.length}/60 samples
                </span>
              }
            >
              <TrendChart history={history} />
            </Card>
          </div>

          {/* ─── Row 3: alerts + report + speed ─────────────────────────── */}
          <div className="col-span-12 xl:col-span-5">
            <Card
              title="Alerts & Event Log"
              subtitle="Newest first"
              action={
                state && state.alerts.length > 0 ? (
                  <span className="pill-base border border-amber-400/30 bg-amber-400/10 text-amber-300">
                    {state.alerts.length} active
                  </span>
                ) : undefined
              }
            >
              {connecting ? (
                <div className="space-y-2">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              ) : (
                <AlertList alerts={state?.alerts ?? []} />
              )}
            </Card>
          </div>

          {ENABLE_REPORT && (
            <div className="col-span-12 xl:col-span-7">
              <ReportCard state={state ?? null} />
            </div>
          )}

          {ENABLE_SPEED && (
            <div className={ENABLE_REPORT ? "col-span-12" : "col-span-12 xl:col-span-7"}>
              <Card
                title="Speed Alerts"
                subtitle="Estimated from video — not for enforcement"
              >
                <SpeedAlertsTable limit={50} />
              </Card>
            </div>
          )}

          {ENABLE_PLATES && (
            <div className="col-span-12 xl:col-span-5">
              <Card
                title="Plate Recognition"
                subtitle="Optional module — placeholder"
              >
                <div className="flex h-full min-h-[160px] flex-col items-center justify-center rounded-lg border border-dashed border-control-700 text-center">
                  <PlateIcon />
                  <p className="mt-2 text-sm text-slate-400">
                    Plate recognition is enabled but not yet implemented.
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    Wire a backend endpoint in <code className="text-slate-400">src/api/endpoints.ts</code> to populate this panel.
                  </p>
                </div>
              </Card>
            </div>
          )}
        </div>

        <Footer />
      </main>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Header
// ─────────────────────────────────────────────────────────────────────────────

function Header({
  status,
  isMock,
}: {
  status: ReturnType<typeof useTrafficStream>["status"];
  isMock: boolean;
}) {
  return (
    <header className="sticky top-0 z-30 border-b border-control-800 bg-control-950/80 backdrop-blur supports-[backdrop-filter]:bg-control-950/70">
      <div className="mx-auto flex max-w-[1600px] items-center justify-between gap-3 px-4 py-3 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3">
          <Logo />
          <div>
            <h1 className="text-base font-bold leading-tight text-slate-100 sm:text-lg">
              Bahir Dar AI Traffic Management
            </h1>
            <p className="text-[11px] text-slate-500 sm:text-xs">
              Real-time intersection monitoring &amp; signal advisory
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span
            className="pill-base border border-amber-400/40 bg-amber-400/10 text-amber-300"
            title="This dashboard is a demo and does not control real traffic equipment."
          >
            <WarnIcon small />
            Simulation — not a real traffic controller
          </span>
          <StatusPill status={status} isMock={isMock} />
        </div>
      </div>
    </header>
  );
}

function Logo() {
  return (
    <div
      aria-hidden="true"
      className="flex h-9 w-9 items-center justify-center rounded-lg border border-control-700 bg-control-900"
    >
      <svg viewBox="0 0 24 24" className="h-5 w-5" aria-hidden="true">
        <circle cx="12" cy="6" r="3" fill="#22c55e" />
        <circle cx="12" cy="12" r="3" fill="#eab308" opacity="0.85" />
        <circle cx="12" cy="18" r="3" fill="#ef4444" />
      </svg>
    </div>
  );
}

function Footer() {
  return (
    <footer className="mt-8 flex flex-col items-start justify-between gap-2 border-t border-control-800 pt-4 text-xs text-slate-500 sm:flex-row sm:items-center">
      <p>
        Hackathon demo · Frontend only displays backend data · No signal logic computed in the browser
      </p>
      <p>
        Mode: <span className="font-mono text-slate-400">{USE_MOCK ? "Mock" : "Live WebSocket"}</span>
        {ENABLE_REPORT && <> · Report</>}
        {ENABLE_SPEED && <> · Speed</>}
        {ENABLE_PLATES && <> · Plates</>}
      </p>
    </footer>
  );
}

function SkeletonStat() {
  return (
    <div className="card-base p-4">
      <Skeleton className="h-3 w-16" />
      <div className="mt-3">
        <Skeleton className="h-9 w-16" />
      </div>
      <div className="mt-3">
        <Skeleton className="h-3 w-24" />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Tiny inline icons
// ─────────────────────────────────────────────────────────────────────────────

function CarIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-4 w-4"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M5 13l1.5-4.5A2 2 0 0 1 8.4 7h7.2a2 2 0 0 1 1.9 1.5L19 13" />
      <path d="M3 13h18v5H3z" />
      <circle cx="7" cy="18" r="1.5" />
      <circle cx="17" cy="18" r="1.5" />
    </svg>
  );
}

function PersonIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-4 w-4"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="12" cy="6" r="2.5" />
      <path d="M6 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2" />
    </svg>
  );
}

function WarnIcon({ small = false }: { small?: boolean }) {
  const size = small ? "h-3.5 w-3.5" : "h-8 w-8";
  return (
    <svg
      viewBox="0 0 24 24"
      className={size}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M12 3 2 21h20L12 3z" />
      <path d="M12 10v5" />
      <path d="M12 18h.01" />
    </svg>
  );
}

function PlateIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-8 w-8 text-slate-500"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <rect x="3" y="7" width="18" height="10" rx="2" />
      <path d="M7 11h2M11 11h2M15 11h2M7 14h10" />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function formatClock(ms: number): string {
  return new Date(ms).toLocaleTimeString(undefined, {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}
