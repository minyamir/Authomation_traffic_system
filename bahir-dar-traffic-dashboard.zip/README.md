# Bahir Dar AI Traffic Management

A hackathon demo dashboard that displays the output of a Python **FastAPI** backend
that analyzes a traffic video — vehicle detection, congestion, signal-timing
recommendation, and pedestrian-crossing simulation.

> ⚠️ **Simulation — not a real traffic controller.**
> This dashboard is a demo. It only **displays** backend data; it never computes
> signal logic itself and must never be wired to real traffic-control equipment.

Built with **React + Vite + TypeScript + Tailwind CSS** and **recharts**.

---

## Quick start

```bash
# 1. Install dependencies
npm install

# 2. (optional) copy env defaults
cp .env.example .env

# 3. Start the dev server
npm run dev
```

Open the printed URL (default <http://localhost:5173>). With the default `.env`
the dashboard runs in **mock mode** — no backend required — and cycles through a
realistic signal sequence every second.

### Scripts

| Script              | Purpose                                  |
| ------------------- | ---------------------------------------- |
| `npm run dev`       | Vite dev server with HMR                 |
| `npm run build`     | Type-check + production build to `dist/` |
| `npm run preview`   | Preview the production build locally     |
| `npm run typecheck` | Run `tsc` only                           |

---

## Environment variables

All client-exposed variables **must** be prefixed with `VITE_`. Defaults ship in
`.env`; copy `.env.example` for a clean starting point.

| Variable              | Default                     | Description                                                        |
| --------------------- | --------------------------- | ------------------------------------------------------------------ |
| `VITE_API_URL`        | `http://localhost:8000`     | Base URL for REST endpoints (used by `src/api/client.ts`).         |
| `VITE_WS_URL`         | `ws://localhost:8000/ws`    | WebSocket URL for the live traffic stream.                         |
| `VITE_USE_MOCK`       | `true`                      | When `true`, use the in-browser mock emitter instead of the API.   |
| `VITE_ENABLE_REPORT`  | `false`                     | Show the **AI Traffic Report** card + Generate-report button.      |
| `VITE_ENABLE_SPEED`   | `false`                     | Show the **Speed Alerts** table (estimated speed only).            |
| `VITE_ENABLE_PLATES`  | `false`                     | Show the **Plate Recognition** placeholder panel.                  |

---

## Switching from mock to the real backend

1. Open `.env` (or `.env.local`).
2. Set `VITE_USE_MOCK="false"`.
3. Confirm `VITE_API_URL` and `VITE_WS_URL` point at your FastAPI server.
4. Restart `npm run dev`.

If the WebSocket drops, the dashboard shows an **Offline** pill and auto-reconnects
with exponential backoff (500ms → 1s → 2s → … → 8s cap). No UI action required.

---

## Backend endpoints (TODO confirm with backend)

All endpoints live in **one place**: [`src/api/endpoints.ts`](src/api/endpoints.ts).
Adjust them there once the FastAPI routes are confirmed — don't hard-code URLs
elsewhere.

| Method | Path      | Body / Field                          | Response                                   |
| ------ | --------- | ------------------------------------- | ------------------------------------------ |
| `POST` | `/videos` | `multipart/form-data`, field `file`   | `{ id, url, ... }`                         |
| `GET`  | `/health` | —                                     | `{ status: "ok" }`                         |
| `WS`   | `/ws`     | —                                     | Streams `TrafficState` JSON once per tick  |
| `POST` | `/report` | `TrafficState` JSON                   | `{ report: string }` (or `text`/`content`) |

No authentication. The frontend does not invent any backend functionality beyond
these endpoints.

### `TrafficState` schema

```ts
type TrafficState = {
  timestamp: number;              // epoch ms
  vehicleCount: number;
  pedestrianCount: number;
  congestion: "low" | "medium" | "high";
  recommendedGreenSeconds: number;
  vehicleLight: "green" | "yellow" | "red";
  pedestrianSignal: "wait" | "walk";
  alerts: {
    id: string;
    type: string;                 // "congestion" | "safety" | "info" | ...
    message: string;
    time: number;                 // epoch ms
  }[];
};
```

Defined in [`src/types/index.ts`](src/types/index.ts).

---

## Project structure

```
src/
├── api/
│   ├── client.ts        # fetch wrapper, env flags, upload helper
│   ├── endpoints.ts     # ⭐ all backend URLs in one place (TODO confirm)
│   └── mock.ts          # in-browser mock emitter + mock report generator
├── components/
│   ├── AlertList.tsx
│   ├── Card.tsx
│   ├── CongestionBadge.tsx
│   ├── CountdownRing.tsx
│   ├── ErrorBanner.tsx
│   ├── PedestrianSignal.tsx
│   ├── ReportCard.tsx
│   ├── Skeleton.tsx
│   ├── SpeedAlertsTable.tsx
│   ├── StatCard.tsx
│   ├── StatusPill.tsx
│   ├── Toast.tsx
│   ├── TrafficLight.tsx
│   ├── TrendChart.tsx
│   ├── UploadBox.tsx
│   └── VideoPanel.tsx
├── hooks/
│   └── useTrafficStream.ts   # WS + mock fallback + auto-reconnect
├── types/
│   └── index.ts              # TrafficState and friends
├── App.tsx                   # main dashboard layout
├── main.tsx
└── index.css                 # Tailwind base + control-room theme
```

---

## Layout overview

- **Header** — logo, title, **Simulation badge**, connection pill (Live / Offline / Mock).
- **Video panel** (large) — drag-and-drop upload box above a `<video>` element. Empty state: "Upload a traffic clip to begin."
- **Stat cards** — Vehicle count, Pedestrian count, Congestion badge, Recommended green time with a countdown ring.
- **Signal panel** — vertical traffic light (red/yellow/green, only the active light glows) and pedestrian signal (WAIT = red hand, WALK = green walking figure).
- **Trend chart** — recharts line chart of vehicle & pedestrian counts over the last 60 samples.
- **Alerts / event log** — scrollable, newest-first.
- **AI Traffic Report** card — hidden unless `VITE_ENABLE_REPORT="true"`.
- **Speed Alerts** table — hidden unless `VITE_ENABLE_SPEED="true"`. Speed is always labelled **estimated**.
- **Plate Recognition** panel — hidden unless `VITE_ENABLE_PLATES="true"` (placeholder for backend wiring).

---

## Safety features

- **Conflicting signal state**: if the data ever shows `vehicleLight: "green"`
  together with `pedestrianSignal: "walk"`, the dashboard shows a prominent red
  **"Conflicting signal state"** banner and hides the signal panel until the
  conflict clears — instead of rendering the unsafe state silently.
- **Never color-only**: every signal has a text label (`STOP` / `CAUTION` / `GO`
  / `WAIT` / `WALK`) next to its light, plus `aria-label`s for screen readers.
- **Visible focus rings** on all interactive elements.

---

## Quality notes

- Every async action (upload, report generation, stream connect) has explicit
  **loading / success / error** states. Skeletons show while connecting.
- Every button and control is functional — no decorative controls.
- Reusable components live in `src/components/`.
- The frontend never computes signal logic; it only renders what the backend
  (or mock) emits.

---

## License

Hackathon demo. Use at your own risk.
