import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  // Only scan the app entry for dependency pre-bundling — otherwise Vite walks
  // every HTML file under the workspace (including unrelated /skills examples
  // that import packages like `three` which are not in this project).
  optimizeDeps: {
    entries: ["index.html"],
  },
  server: {
    host: true,
    port: 5173,
    fs: {
      allow: [path.resolve(__dirname, "./src"), path.resolve(__dirname)],
    },
    watch: {
      ignored: [
        "**/skills/**",
        "**/download/**",
        "**/node_modules/**",
        "**/.git/**",
      ],
    },
  },
});
